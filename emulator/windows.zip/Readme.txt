﻿DialogEm
Verzija 1.0.2
Opombe in navodila za uporabo

*** Uvod ***

  DialogEm emulira Gorenjev računalnik Dialog; natančneje model Dialog 20 P.

*** Uporaba ***

  Emulator zaľenemo z grafičnim vmesnikom ali z ukazne vrstice brez parametrov.

  Poleg emulatorja mora biti v trenutnem imeniku (oz. imeniku, kjer je
  emulator) še konfiguracijska datoteka - DialogEm.ini.

  Programsko opremo za Dialog lahko dobite na spletni strani emulatorja.

*** Funkcionalnost ***

  V splošnem se lahko vse aplikacije uporabljajo brez težav.

  Nenujne periferne naprave, z izjemo kasetofona in tiskalnika, niso emulirane.

  Emulirani generator znakov še ne podpira vseh znakov, ki so na voljo na
  pravem Dialogu, niti niso njihove oblike vedno točne.

  ROM ni emuliran, vendar je njegova funkcionalnost (nalaganje operacijskega
  sistema z diskete) replicirana v samem emulatorju.

*** Kratek uvod v FEDOS ***

  * DIR prikaže datoteke. DIR ŠFU prikaže vse informacije o njih.
  * DIRS prikaže datoteke s sistemskim atributom.
  * p: (p od A do C) zamenja pogon.
  * n: (n od 0 do 15) zamenja trenutno aktivno uporabniško območje.
  * TYPE izpiše vsebino besedilne datoteke na zaslon.
  * ERA briše datoteke.
  * REN novo=staro preimenuje datoteke.

  Če programa ne znate končati, resetirajte emulirani računalnik.

*** Preslikava tipk na Dialogovi tipkovnici na PC tipkovnico ***

  Večina tipk (npr. A-Z, 0-9) je preslikana tako, kot bi pričakovali.
  Dialogova tipkovnica pa ima še nekaj tipk, ki jih na PC tipkovnici ni.

  Dialog                       PC

  BRK                          F1
  < >                          Insert
  Puščica gor                  Puščica gor ali F5
  Puščica dol                  Puščica dol ali F6
  Puščica levo                 Puščica levo ali F7
  Puščica desno                Puščica desno ali F8
  PF1                          F9, F13 ali Alt+9
  PF2                          F10, F14 ali Alt+0
  PF3                          F11, F15 ali Alt+'
  PF4                          F12, Home ali Alt++
  , (na numerični tipkovnici)  + (na numerični tipkovnici)
  SCR                          tipka levo od 1
  LF                           Page Down

  Na Mac OS in Mac OS X se namesto tipke Alt uporablja Cmd.

*** Tiskanje ***

  V menuju Naprave lahko vključite ali izključite navidezni tiskalnik. Ko je
  vključen, se bodo vsi podatki, poslani na serijska vrata, zapisali v
  datoteko.

*** Uporaba kasetofona ***

  FEBASIC lahko shranjuje programe na kaseto in jih z nje nalaga. Kasete so na
  gostitelju shranjene v obliki WAV datotek.

  Shranjevanje deluje tako, da iz menuja Naprave izberete ukaz Snemanje na
  kasetofon. Emulator vas bo vprašal, v katero datoteko želite snemati. Na
  FEBASICovi ukazni vrstici nato vnesite ukaz SAVE# "ime", kjer ime zamenjajte
  z imenom, pod katerim želite shraniti program (na isti kaseti je lahko
  shranjenih več programov). Ko je shranjevanje končano, še enkrat izberite
  isto možnost iz menuja, da snemanje prekinete.

  Nalaganje deluje podobno, le da iz menuja Naprave izberete ukaz Predvajanje
  s kasetofona in v FEBASICu vnesete ukaz LOAD#. Ime programa je lahko prazno
  (""), če želite, da se naloži prvi program na kaseti. Kaseta se samodejno
  odstrani iz navideznega kasetofona, ko je bila predvajana vsa vsebina na
  njej.

*** Kopiranje in lepljenje besedila ***

  Besedilo kopirate tako, da z miško povlečete čez zaslon in s tem izberete
  besedilo, ki ga želite kopirati. Nato iz menuja Urejanje izberete ukaz
  Kopiraj.

  Besedilo lepite tako, da iz menuja Urejanje izberete ukaz Prilepi. Emulator
  ga bo natipkal namesto vas. Dokler poteka lepljenje, ne morete uporabljati
  tipkovnice, lahko pa lepljenje prekinete.

*** Deljenje (skupna raba) datotek ***

  Datoteke, ki jih položite v mapo Deljeno (ki mora biti v mapi, v kateri je
  emulator), so znotraj FEDOSa dostopne na področju 0 pogona C in obratno.

  Ta funkcionalnost ni združljiva z vsemi programi. Včasih boste morali zato
  datoteke začasno kopirati na emulirano disketo in nazaj z ukazom:

  A:PIP c:=i:spec
  (c je ciljni pogon, i je izvorni pogon, spec je specifikacija datotek, npr.:
  BESEDILO.TXT, *.COM, WS*.*; za kopiranje sistemskih datotek dodajte na konec
  še ŠR)

  To predpostavlja, da imate program PIP.COM na pogonu A.

*** Konfiguracijska datoteka ***

  V datoteki DialogEm.ini, ki mora biti v isti mapi kot emulator, lahko
  določite naslednje možnosti:

  BarvaZaslona  Določa barvo zaslona. Možnosti sta "bela" in "zelena".
  Deljenje      Določa, ali je deljenje datotek omogočeno (1) ali ne (0). Če ta
                možnost manjka, deljenje ni omogočeno.
  DisketaA      Katera slika diskete se bo ob zagonu emulatorja samodejno
                vstavila v disketni pogon A in se uporabila za zagon. Ta
                možnost ni obvezna. Navedete lahko poljubno pot.
  DisketaB      Enako kot DisketaA, vendar za pogon B.

  Prazne vrstice in vrstice, ki se začnejo s podpičjem, se ignorirajo.

*** Znane pomanjkljivosti ***

  Ob zagonu emulirani računalnik misli, da je Caps Lock vključen, tudi če ni.
  To odpravite tako, da Caps Lock pritisnete dvakrat. Ni znano, kako se pravi
  Dialog obnaša v tem oziru.

  Na Mac OS (ne Mac OS X) nekatere tipke ne delujejo, če je izbran slovenski
  razpored tipk. Pred zagonom emulatorja zato izberite ameriškega. To ne vpliva
  na razpored tipk emuliranega računalnika.

  Na Mac OS (ne Mac OS X) se lahko zgodi, da se tipkovnica neha odzivati, če
  preklopite v drug program in nazaj.

  Na datotečnih sistemih, ki so občutljivi na velike in male črke (npr. APFS),
  deljenje datotek morda ne bo delovalo pravilno.

*** Več informacij ***

  http://matejhorvat.si/sl/slorac/gorenje/dialog/